import { db } from './index.ts';
import { reminders, policies } from './schema.ts';
import { and, eq, desc } from 'drizzle-orm';

export async function getReminders(userId: string) {
  try {
    const items = await db
      .select({
        id: reminders.id,
        userId: reminders.userId,
        policyId: reminders.policyId,
        title: reminders.title,
        reminderType: reminders.reminderType,
        dueDate: reminders.dueDate,
        remindDaysBefore: reminders.remindDaysBefore,
        isRead: reminders.isRead,
        isDismissed: reminders.isDismissed,
        createdAt: reminders.createdAt,
        policyName: policies.policyName,
        companyName: policies.companyName,
      })
      .from(reminders)
      .leftJoin(policies, eq(reminders.policyId, policies.id))
      .where(and(eq(reminders.userId, userId), eq(reminders.isDismissed, false)))
      .orderBy(desc(reminders.dueDate));

    return items;
  } catch (error) {
    console.error('getReminders error:', error);
    throw new Error('Failed to fetch reminders', { cause: error });
  }
}

export async function createReminder(
  userId: string,
  data: {
    policyId?: number;
    title: string;
    reminderType: string;
    dueDate: string;
    remindDaysBefore?: number;
  }
) {
  try {
    const inserted = await db
      .insert(reminders)
      .values({
        userId,
        policyId: data.policyId ? Number(data.policyId) : null,
        title: data.title,
        reminderType: data.reminderType,
        dueDate: data.dueDate,
        remindDaysBefore: data.remindDaysBefore || 7,
      })
      .returning();
    return inserted[0];
  } catch (error) {
    console.error('createReminder error:', error);
    throw new Error('Failed to create reminder', { cause: error });
  }
}

export async function markReminderRead(userId: string, id: number) {
  try {
    const updated = await db
      .update(reminders)
      .set({ isRead: true })
      .where(and(eq(reminders.id, id), eq(reminders.userId, userId)))
      .returning();
    return updated[0] || null;
  } catch (error) {
    console.error('markReminderRead error:', error);
    throw new Error('Failed to update reminder', { cause: error });
  }
}

export async function dismissReminder(userId: string, id: number) {
  try {
    const updated = await db
      .update(reminders)
      .set({ isDismissed: true })
      .where(and(eq(reminders.id, id), eq(reminders.userId, userId)))
      .returning();
    return updated[0] || null;
  } catch (error) {
    console.error('dismissReminder error:', error);
    throw new Error('Failed to dismiss reminder', { cause: error });
  }
}

export async function deleteReminder(userId: string, id: number) {
  try {
    const deleted = await db
      .delete(reminders)
      .where(and(eq(reminders.id, id), eq(reminders.userId, userId)))
      .returning();
    return deleted[0] || null;
  } catch (error) {
    console.error('deleteReminder error:', error);
    throw new Error('Failed to delete reminder', { cause: error });
  }
}

