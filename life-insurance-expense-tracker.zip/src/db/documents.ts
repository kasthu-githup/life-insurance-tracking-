import { db } from './index.ts';
import { documents, policies } from './schema.ts';
import { and, eq, desc } from 'drizzle-orm';

export async function getDocuments(userId: string, policyId?: number) {
  try {
    const conditions = [eq(documents.userId, userId)];
    if (policyId) {
      conditions.push(eq(documents.policyId, policyId));
    }

    const items = await db
      .select({
        id: documents.id,
        userId: documents.userId,
        policyId: documents.policyId,
        documentName: documents.documentName,
        documentType: documents.documentType,
        fileUrl: documents.fileUrl,
        fileSize: documents.fileSize,
        uploadDate: documents.uploadDate,
        notes: documents.notes,
        createdAt: documents.createdAt,
        policyName: policies.policyName,
        companyName: policies.companyName,
      })
      .from(documents)
      .leftJoin(policies, eq(documents.policyId, policies.id))
      .where(and(...conditions))
      .orderBy(desc(documents.uploadDate));

    return items;
  } catch (error) {
    console.error('getDocuments error:', error);
    throw new Error('Failed to fetch documents', { cause: error });
  }
}

export async function createDocument(
  userId: string,
  data: {
    policyId?: number;
    documentName: string;
    documentType: string;
    fileUrl: string;
    fileSize?: string;
    uploadDate: string;
    notes?: string;
  }
) {
  try {
    const inserted = await db
      .insert(documents)
      .values({
        userId,
        policyId: data.policyId ? Number(data.policyId) : null,
        documentName: data.documentName,
        documentType: data.documentType,
        fileUrl: data.fileUrl,
        fileSize: data.fileSize || '1.2 MB',
        uploadDate: data.uploadDate,
        notes: data.notes || '',
      })
      .returning();
    return inserted[0];
  } catch (error) {
    console.error('createDocument error:', error);
    throw new Error('Failed to add document record', { cause: error });
  }
}

export async function deleteDocument(userId: string, id: number) {
  try {
    const deleted = await db
      .delete(documents)
      .where(and(eq(documents.id, id), eq(documents.userId, userId)))
      .returning();
    return deleted[0] || null;
  } catch (error) {
    console.error('deleteDocument error:', error);
    throw new Error('Failed to delete document', { cause: error });
  }
}
