import { db } from './index.ts';
import { policies, expenses, payments, beneficiaries, documents, reminders } from './schema.ts';
import { and, eq, desc } from 'drizzle-orm';

export async function getPolicies(userId: string) {
  try {
    return await db
      .select()
      .from(policies)
      .where(eq(policies.userId, userId))
      .orderBy(desc(policies.createdAt));
  } catch (error) {
    console.error('getPolicies error:', error);
    throw new Error('Failed to fetch policies', { cause: error });
  }
}

export async function getPolicyById(userId: string, id: number) {
  try {
    const policyList = await db
      .select()
      .from(policies)
      .where(and(eq(policies.id, id), eq(policies.userId, userId)))
      .limit(1);

    if (!policyList.length) return null;

    const policy = policyList[0];
    const policyExpenses = await db
      .select()
      .from(expenses)
      .where(and(eq(expenses.policyId, id), eq(expenses.userId, userId)))
      .orderBy(desc(expenses.expenseDate));

    const policyPayments = await db
      .select()
      .from(payments)
      .where(and(eq(payments.policyId, id), eq(payments.userId, userId)))
      .orderBy(desc(payments.dueDate));

    const policyBeneficiaries = await db
      .select()
      .from(beneficiaries)
      .where(and(eq(beneficiaries.policyId, id), eq(beneficiaries.userId, userId)));

    const policyDocs = await db
      .select()
      .from(documents)
      .where(and(eq(documents.policyId, id), eq(documents.userId, userId)));

    return {
      ...policy,
      expenses: policyExpenses,
      payments: policyPayments,
      beneficiaries: policyBeneficiaries,
      documents: policyDocs,
    };
  } catch (error) {
    console.error('getPolicyById error:', error);
    throw new Error('Failed to fetch policy details', { cause: error });
  }
}

export async function createPolicy(
  userId: string,
  data: {
    policyName: string;
    companyName: string;
    policyNumber: string;
    policyType: string;
    policyHolder: string;
    startDate: string;
    endDate?: string;
    premiumAmount: number;
    premiumFrequency: string;
    nextDueDate: string;
    sumAssured?: number;
    paymentMethod?: string;
    nomineeName?: string;
    nomineeRelation?: string;
    status?: string;
    notes?: string;
  }
) {
  try {
    const inserted = await db
      .insert(policies)
      .values({
        userId,
        policyName: data.policyName,
        companyName: data.companyName,
        policyNumber: data.policyNumber,
        policyType: data.policyType,
        policyHolder: data.policyHolder,
        startDate: data.startDate,
        endDate: data.endDate || null,
        premiumAmount: Number(data.premiumAmount),
        premiumFrequency: data.premiumFrequency,
        nextDueDate: data.nextDueDate,
        sumAssured: Number(data.sumAssured || 0),
        paymentMethod: data.paymentMethod || 'Net Banking',
        nomineeName: data.nomineeName || '',
        nomineeRelation: data.nomineeRelation || '',
        status: data.status || 'Active',
        notes: data.notes || '',
      })
      .returning();

    const newPolicy = inserted[0];

    // Automatically create the upcoming payment schedule for this policy
    await db.insert(payments).values({
      userId,
      policyId: newPolicy.id,
      amount: newPolicy.premiumAmount,
      dueDate: newPolicy.nextDueDate,
      status: 'Upcoming',
      paymentMethod: newPolicy.paymentMethod || 'Net Banking',
      notes: `Scheduled ${newPolicy.premiumFrequency} premium for ${newPolicy.policyName}`,
    });

    // Create a reminder
    await db.insert(reminders).values({
      userId,
      policyId: newPolicy.id,
      title: `${newPolicy.policyName} Premium Due`,
      reminderType: 'Premium Due',
      dueDate: newPolicy.nextDueDate,
      remindDaysBefore: 7,
    });

    if (data.nomineeName) {
      await db.insert(beneficiaries).values({
        userId,
        policyId: newPolicy.id,
        name: data.nomineeName,
        relationship: data.nomineeRelation || 'Nominee',
        sharePercentage: 100,
      });
    }

    return newPolicy;
  } catch (error) {
    console.error('createPolicy error:', error);
    throw new Error('Failed to create policy', { cause: error });
  }
}

export async function updatePolicy(
  userId: string,
  id: number,
  data: Partial<typeof policies.$inferInsert>
) {
  try {
    const updated = await db
      .update(policies)
      .set(data)
      .where(and(eq(policies.id, id), eq(policies.userId, userId)))
      .returning();
    return updated[0] || null;
  } catch (error) {
    console.error('updatePolicy error:', error);
    throw new Error('Failed to update policy', { cause: error });
  }
}

export async function deletePolicy(userId: string, id: number) {
  try {
    // Safely delete all policy-dependent child records first
    await db.delete(payments).where(and(eq(payments.policyId, id), eq(payments.userId, userId)));
    await db.delete(expenses).where(and(eq(expenses.policyId, id), eq(expenses.userId, userId)));
    await db.delete(reminders).where(and(eq(reminders.policyId, id), eq(reminders.userId, userId)));
    await db.delete(documents).where(and(eq(documents.policyId, id), eq(documents.userId, userId)));
    await db.delete(beneficiaries).where(and(eq(beneficiaries.policyId, id), eq(beneficiaries.userId, userId)));

    const deleted = await db
      .delete(policies)
      .where(and(eq(policies.id, id), eq(policies.userId, userId)))
      .returning();
    return deleted[0] || null;
  } catch (error) {
    console.error('deletePolicy error:', error);
    throw new Error('Failed to delete policy', { cause: error });
  }
}
