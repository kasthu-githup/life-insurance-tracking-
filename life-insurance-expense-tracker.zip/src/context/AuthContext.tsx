import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { signInWithPopup, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { UserProfile } from '../types.ts';

interface AuthContextType {
  user: { uid: string; email: string; name: string } | null;
  profile: UserProfile | null;
  token: string | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string, name?: string) => Promise<void>;
  signupWithEmail: (data: { fullName: string; email: string; phone?: string }) => Promise<void>;
  loginAsDemo: () => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ uid: string; email: string; name: string } | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync token and user with backend
  const syncWithBackend = async (idToken: string, fallbackName?: string) => {
    try {
      const res = await fetch('/api/auth/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({ fullName: fallbackName || 'Kasthuri' }),
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data.user);
      }
    } catch (err) {
      console.error('Failed to sync auth with backend:', err);
    }
  };

  const refreshProfile = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
      }
    } catch (err) {
      console.error('Failed to refresh profile:', err);
    }
  };

  useEffect(() => {
    // Check for demo user in session
    const savedDemo = sessionStorage.getItem('lifetrack_demo_user');
    if (savedDemo) {
      try {
        const parsed = JSON.parse(savedDemo);
        setUser(parsed);
        const demoToken = `demo-token-${parsed.uid}`;
        setToken(demoToken);
        syncWithBackend(demoToken, parsed.name).finally(() => setLoading(false));
        return;
      } catch (e) {
        sessionStorage.removeItem('lifetrack_demo_user');
      }
    }

    // Listen to Firebase auth state
    const unsubscribe = onAuthStateChanged(auth, async (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        try {
          const idToken = await fbUser.getIdToken();
          const u = {
            uid: fbUser.uid,
            email: fbUser.email || '',
            name: fbUser.displayName || 'Kasthuri',
          };
          setUser(u);
          setToken(idToken);
          await syncWithBackend(idToken, u.name);
        } catch (error) {
          console.error('Error fetching token:', error);
        }
      } else if (!sessionStorage.getItem('lifetrack_demo_user')) {
        setUser(null);
        setToken(null);
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      setLoading(true);
      const result = await signInWithPopup(auth, googleAuthProvider);
      const idToken = await result.user.getIdToken();
      const u = {
        uid: result.user.uid,
        email: result.user.email || '',
        name: result.user.displayName || 'LifeTrack User',
      };
      sessionStorage.removeItem('lifetrack_demo_user');
      setUser(u);
      setToken(idToken);
      await syncWithBackend(idToken, u.name);
    } catch (err: any) {
      console.error('Google sign in error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginWithEmail = async (email: string, _pass: string, name?: string) => {
    setLoading(true);
    try {
      // Clean identifier from email
      const cleanUid = 'usr_' + email.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
      const demoUser = {
        uid: cleanUid,
        email,
        name: name || (email.split('@')[0] ? email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1) : 'Kasthuri'),
      };
      sessionStorage.setItem('lifetrack_demo_user', JSON.stringify(demoUser));
      setUser(demoUser);
      const demoToken = `demo-token-${demoUser.uid}`;
      setToken(demoToken);
      await syncWithBackend(demoToken, demoUser.name);
    } finally {
      setLoading(false);
    }
  };

  const signupWithEmail = async (data: { fullName: string; email: string; phone?: string }) => {
    setLoading(true);
    try {
      const cleanUid = 'usr_' + data.email.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
      const demoUser = {
        uid: cleanUid,
        email: data.email,
        name: data.fullName,
      };
      sessionStorage.setItem('lifetrack_demo_user', JSON.stringify(demoUser));
      setUser(demoUser);
      const demoToken = `demo-token-${demoUser.uid}`;
      setToken(demoToken);
      await syncWithBackend(demoToken, data.fullName);
    } finally {
      setLoading(false);
    }
  };

  const loginAsDemo = async () => {
    await loginWithEmail('kasthuri.raman@example.com', 'demo123', 'Kasthuri');
  };

  const logout = async () => {
    sessionStorage.removeItem('lifetrack_demo_user');
    setUser(null);
    setToken(null);
    setProfile(null);
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        token,
        loading,
        signInWithGoogle,
        loginWithEmail,
        signupWithEmail,
        loginAsDemo,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
